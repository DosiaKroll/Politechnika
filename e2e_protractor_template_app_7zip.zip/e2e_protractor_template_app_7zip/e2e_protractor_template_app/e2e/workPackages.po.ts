import { browser, by, element } from 'protractor';

export class WorkPackagesPage {

    constructor() { }
}