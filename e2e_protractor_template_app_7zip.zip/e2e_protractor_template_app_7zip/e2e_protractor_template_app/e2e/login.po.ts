import { browser, by, element } from 'protractor';
import { protractor } from 'protractor/built/ptor';

export class LoginPage {

  url = '/login';
  constructor() { }

  navigateTo() {
    return browser.get(this.url);
  }
}
