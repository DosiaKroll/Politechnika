import { browser, element, by } from 'protractor';
import { LoginPage } from './login.po';
import { WorkPackagesPage } from './workPackages.po';

describe('OpenProject Page', () => {

  const loginPage = new LoginPage();
  const workPackagesPage = new WorkPackagesPage();

  beforeEach(() => {
    
  });

  it('should login to open project page', () => {
    
  });
});